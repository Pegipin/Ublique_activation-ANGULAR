 import { HttpClient } from "@angular/common/http";
import { Component, OnDestroy, OnInit, ViewChild } from "@angular/core";
import {
  MatDialog,
  MatSidenav,
  MatTableDataSource,
  PageEvent,
MatSelectModule
} from "@angular/material";
import { Observable, Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { AddEditCentriAutomezziProdottoDialogComponent } from "src/app/dialogs/add-edit-centri-automezzi-prodotto-dialog/add-edit-centri-automezzi-prodotto-dialog.component";
import { LogisticCenterEntity } from "src/app/entity/Logistic_Center";
import { RainbowUbliqueActivationEntity,  RainbowUbliqueActivationEntity_List,
} from "src/app/entity/Rainbow_Ublique_Activation.entity";
import { EOTArtBaseEntity } from "src/app/entity/Tart_Base_entity";
import { ApiService } from "src/app/services/api.service";
import Swal, { SweetAlertResult } from 'sweetalert2'



@Component({
  selector: "app-list-centri-automezzi-prodotto",
  templateUrl: "./list-centri-automezzi-prodotto.component.html",
  styleUrls: ["./list-centri-automezzi-prodotto.component.css"],
})
export class ListCentriAutomezziProdottoComponent implements OnInit {
  displayedColumns: string[] = [
    "action",
    "logisticcenter",
    "baseproduct",
    "demandplanningactive",
  ];
  dataSource: MatTableDataSource<RainbowUbliqueActivationEntity> =   new MatTableDataSource<RainbowUbliqueActivationEntity>();
  listProducts: EOTArtBaseEntity[] = [];
   listLogistics: LogisticCenterEntity[] = [];
   productModel=new EOTArtBaseEntity();

   private _unsubscribeAll: Subject<any>;
  error: boolean;


  constructor(public dialog: MatDialog,
     private _apiservice: ApiService,
     ) {}

  ngOnInit() {
    this._apiservice
      .ListRainbowUbliqueActivation()
      .subscribe((res: RainbowUbliqueActivationEntity_List) => {

        this.dataSource.data = res.ubliqueActivationList;

        this._apiservice
          .ListArtBase()
          .subscribe((products: EOTArtBaseEntity[]) => {
            this.listProducts = products;

          });

          this._apiservice
          .ListLogisticCenter()
          .subscribe((centers: LogisticCenterEntity[]) => {
          this. listLogistics = centers;
          });
      });
  }

  onClickAddBU() {
    const dialogRef = this.dialog.open(
      AddEditCentriAutomezziProdottoDialogComponent,
      {
        width: "50vw",
      }
    );
    dialogRef.afterClosed().subscribe((res) => {
      this._apiservice.ListRainbowUbliqueActivation()
      .subscribe((res: RainbowUbliqueActivationEntity_List) => {
        this.dataSource.data = res.ubliqueActivationList;
    });
  })
  }


  // onDelete(item: RainbowUbliqueActivationEntity) {
  //   Swal.fire({
  //     title: "Elimina Logistic Center/Base Product ",
  //     text:
  //       "Stai per eliminare: " + item.logisticcenter + " / " + item.baseproduct,
  //     type: "warning",
  //     showCancelButton: true,
  //     confirmButtonText: "Si",
  //     cancelButtonText: "No, annulla eliminazione"
  //   }).then((result: SweetAlertResult) => {

  //     let entity: RainbowUbliqueActivationEntity = new RainbowUbliqueActivationEntity;
  //     entity.id=0


  //    if(this.error==false){
  //     this._apiservice.DeleteRainbowUbliqueActivation(entity).pipe(takeUntil(this._unsubscribeAll)).subscribe( res => {
  //     if (res) {
  //       this._apiservice
  //       .ListRainbowUbliqueActivation()
  //       .subscribe((res: RainbowUbliqueActivationEntity_List) => {

  //         this.dataSource.data = res.ubliqueActivationList;
  //       });
  //       }
  //     });
  //   }
  // })
  // }



  onDelete(item: RainbowUbliqueActivationEntity) {
    Swal.fire({
      title: "Elimina Product " + this.getProductDescription(item.baseproduct),
      text:
        "Stai per eliminare " + this.getProductDescription(item.baseproduct),
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Si, eliminalo",
      cancelButtonText: "No, annulla eliminazione",
    }).then((result) => {
      if (result.value) {
        let entity: RainbowUbliqueActivationEntity = new RainbowUbliqueActivationEntity();

        entity.id;

        this._apiservice
          .DeleteRainbowUbliqueActivation(item.id)

          .subscribe((item:RainbowUbliqueActivationEntity) => {
            Swal.fire({
              title: "The product has been Deleted!",
              type: "success",
            });
            this._apiservice
      .ListRainbowUbliqueActivation()
      .subscribe((res: RainbowUbliqueActivationEntity_List) => {

        this.dataSource.data = res.ubliqueActivationList;
              });
          });
      }
    });

}








































  onPlay(item: RainbowUbliqueActivationEntity) {
    Swal.fire({
      title: "Attiva Logistic Center/Base Product ",
      text:
        "Stai per attivare: " + item.logisticcenter + " / " + item.baseproduct,
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Si, attiva",
      cancelButtonText: "No, annulla",
    }).then((result) => {
      if (result.value) {
      }
    });
  }

  onStop(item: RainbowUbliqueActivationEntity) {
    Swal.fire({
      title: "Stop Logistic Center/Base Product ",
      text:
        "Stai per bloccare: " + item.logisticcenter + " / " + item.baseproduct,
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Si, blocca",
      cancelButtonText: "No, annulla",
    }).then((result) => {
      if (result.value) {
      }
    });
  }

  getProductDescription(productCode: string) {

    const found = this.listProducts.find(
      prod => prod.artbase.art_base == productCode

    );
        return found? found.artbase.art_base+" " +" "+found.artbase.breve  : "";

    }

   getLogisticCenter(logisticCode: string) {

     const found = this.listLogistics.find(
     logic => logic.CA == logisticCode

  );
      return found? found.CA +" "+found.CABreve  : "";


  }


applyFilter(filterValue: string){
this.dataSource.filter=filterValue.trim().toLowerCase();
}
  }





