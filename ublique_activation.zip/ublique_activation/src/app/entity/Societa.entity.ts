export interface SocietaEntity {
    so_id: number;
    so_codice: string;
    so_nome: string;
    so_breve: string;
    so_insertuser: string;
    so_insertdate: Date;
    so_updateuser: string;
    so_updatedate: Date;
    so_delete: number;
    so_deleteuser: string;
    so_deletedate: Date;
    databasemagoid: number;
  }
