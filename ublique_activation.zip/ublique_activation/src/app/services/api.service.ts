import { HttpClient } from '@angular/common/http';
import { Injectable, } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Context } from 'src/Service/DNN/context.service';
import { LogisticCenterEntity } from '../entity/Logistic_Center';
import { RainbowUbliqueActivationEntity, RainbowUbliqueActivationEntity_List } from '../entity/Rainbow_Ublique_Activation.entity';
import { SocietaEntity } from '../entity/Societa.entity';
import{EOTArtBaseEntity, TArtBaseEntity}from '../entity/Tart_Base_entity';

@Injectable({
  providedIn: 'root'
})
export class ApiService {


  RainbowUbliqueActivationSet(entity: RainbowUbliqueActivationEntity) {
    throw new Error('Method not implemented.');
  }
  RainbowUbliqueActivation(entity: RainbowUbliqueActivationEntity) {
    throw new Error('Method not implemented.');
  }

  private api_uri: string;
  private listRainbowUbliqueActivation: string = "RainbowUbliqueActivation/list";
  private listArtBase: string = "TArtBase/List";
  private listlogisticCenter:string="LogisticCenter/List "
  public setRainbowUbliqueActivation = "RainbowUbliqueActivation/Set ";
  public deleteRainbowUbliqueActivation = "RainbowUbliqueActivation/Delete ";

  constructor(
    private context: Context,
    private httpClient: HttpClient,
    private snackbar: MatSnackBar
  ) {
    this.api_uri = this.context._properties.routingWebAPI;
  }

  ListRainbowUbliqueActivation(): Observable<RainbowUbliqueActivationEntity_List> {
    return this.httpClient.get(
        `${this.api_uri}${this.listRainbowUbliqueActivation}`
      )
      .pipe(
        map((data: string) => {
          return JSON.parse(data) as RainbowUbliqueActivationEntity_List;
        }),
        catchError((err) => {
          return this.handleError(err);
        })
      );
  }


ListArtBase(): Observable<EOTArtBaseEntity[]> {
  return this.httpClient.get(
      `${this.api_uri}${this.listArtBase}`
    )
    .pipe(
      map((data: string) => {
        return JSON.parse(data) as EOTArtBaseEntity[];
      }),
      catchError((err) => {
        return this.handleError(err);
      })
    );
}

ListLogisticCenter(): Observable<LogisticCenterEntity[]> {
  return this.httpClient.get(
    `${this.api_uri}${this.listlogisticCenter}`
  )
  .pipe(
    map((data: string) => {
      return JSON.parse(data) as LogisticCenterEntity[];
    }),
    catchError((err) => {
      return this.handleError(err);
    })
  );

}


SetRainbowUbliqueActivation(entity: RainbowUbliqueActivationEntity): Observable<RainbowUbliqueActivationEntity> {

  let params: any;
  params = JSON.stringify(entity);
  return this.httpClient.post(`${this.api_uri}${this.setRainbowUbliqueActivation}`, params)

    .pipe(

      map((data: any) => {return JSON.parse(data) as RainbowUbliqueActivationEntity;

      }),

     catchError((err) => {
        return this.handleError(err);

      })

    );

}


DeleteRainbowUbliqueActivation(entity: number): Observable<RainbowUbliqueActivationEntity> {

  let params: any;
  params = JSON.stringify(entity);
  return this.httpClient.post(`${this.api_uri}${this.deleteRainbowUbliqueActivation}`, params)

    .pipe(

      map((data: any) => {return JSON.parse(data) as RainbowUbliqueActivationEntity;

      }),

     catchError((err) => {
        return this.handleError(err);

      })

    );

}









private handleError(err: any): Observable<any> {
  if (err.status !== 404) {
    this.openErrorSnackbar(err);
    return throwError(err);
  }
  else {
    return of<any>(null);
  }
}

private openErrorSnackbar(err) {
  if (err.status !== 404) {
    const errorMessage = err && err.message ? err.message : "Errors have occurred. Please try again later.";
    this.snackbar.open(errorMessage, null, { duration: 6000 });
  }
}

// AreaBranchListOrderBranch(RowspPage:number,PageNumber:number,AreaActive:boolean) {
//   return this.httpClient.get<any>(
//     `${this.api_uri}${this.areaBranchListOrderBranch}?RowspPage=${RowspPage}&PageNumber=${PageNumber}&AreaActive=${AreaActive}`
//   )
//   .pipe(
//     map((data: any) => {
//       return data;
//     }),
//     catchError(err => {
//       if (err.status !== 404) {
//         this.snackbar.open(err.error && err.error !== '' ? err.error : err.message, "", {duration: 10000});
//       }
//       return of(null);
//     })
//   );
// }

UserDelete(element) {
  let params: any;

  params = JSON.stringify(element);
  return this.httpClient.post<SocietaEntity>(`${this.api_uri}ARMUser/delete`, params)
  .pipe(
    map((data: any) => {
      return data;
    }),
    catchError(err => {
      if (err.status !== 404) {
        this.snackbar.open(err.error && err.error !== '' ? err.error : err.message, "", {duration: 10000});
      }
      return of(null);
    })
  );
}




}
